import type { Customer } from '../lib/types';

interface Props {
  c: Customer;
  onAccept: (id: string) => void;
  onDecline: (id: string) => void;
}

/**
 * Card representing a single customer and their order.
 *
 * Shows the customer's name, the price of their order, a simple list of
 * icons (currently just item names), a patience bar that shrinks over
 * time, and accept/decline buttons. When the order is accepted, the card
 * shows a waiting state instead of buttons.
 */
export default function CustomerCard({ c, onAccept, onDecline }: Props) {
  // Compute patience percentage. In a production game we'd want to use the
  // game's internal time instead of `Date.now()`, but for a static demo
  // this suffices.
  const pct = Math.max(0, ((c.patienceEndsAt - Date.now()) / 45000) * 100);

  return (
    <div className="w-56 bg-white rounded-2xl shadow p-4 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="font-semibold">{c.name}</span>
        <span className="text-sm text-slate-500">${c.order.price}</span>
      </div>
      <div className="flex gap-2">
        {c.order.items.map((i) => (
          <span key={i.item} className="px-2 py-1 bg-slate-100 rounded text-xs capitalize">
            {i.item}
          </span>
        ))}
      </div>
      <div className="h-2 w-full bg-slate-200 rounded">
        <div
          className="h-2 bg-amber-500 rounded"
          style={{ width: pct + '%' }}
        />
      </div>
      {!c.accepted ? (
        <div className="flex gap-2">
          <button
            className="flex-1 btn-primary"
            onClick={() => onAccept(c.id)}
          >
            Accept
          </button>
          <button
            className="flex-1 btn-ghost"
            onClick={() => onDecline(c.id)}
          >
            Decline
          </button>
        </div>
      ) : (
        <div className="text-xs text-slate-500">Waiting…</div>
      )}
    </div>
  );
}