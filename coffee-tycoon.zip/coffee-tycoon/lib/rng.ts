/**
 * Simple pseudo‑random utilities for Coffee Tycoon.
 *
 * The production game may want deterministic names and spawn timing,
 * seeded off the player's session. For the MVP skeleton we simply use
 * Math.random() and a small list of names. If deterministic behaviour
 * becomes important, you can replace these with a seedable RNG library.
 */

const names = [
  'Alex',
  'Sam',
  'Jordan',
  'Taylor',
  'Riley',
  'Casey',
  'Jamie',
  'Morgan',
  'Reese',
  'Drew',
];

export function randomName(): string {
  return names[Math.floor(Math.random() * names.length)];
}

/**
 * Generate a random integer between `min` and `max` inclusive. Useful for
 * spawning customers at varied intervals.
 */
export function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}