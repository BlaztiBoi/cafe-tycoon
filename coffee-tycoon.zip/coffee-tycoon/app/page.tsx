import HUD from '../components/HUD';
import Workstation from '../components/Workstation';
import CustomersRow from '../components/CustomersRow';
import ShopDrawer from '../components/ShopDrawer';

/**
 * Main game page.
 *
 * This page composes the high‑level UI sections: the HUD, the workstation,
 * the customer row, and the shop drawer. Actual game logic is handled via
 * the Zustand store; these components simply subscribe to state and
 * dispatch actions when users interact with the UI.
 */
export default function HomePage() {
  return (
    <main className="flex flex-col min-h-screen">
      <HUD />
      <Workstation />
      <CustomersRow />
      <ShopDrawer />
    </main>
  );
}