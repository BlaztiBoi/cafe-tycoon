import type { ReactNode } from 'react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  children: ReactNode;
}

/**
 * Generic modal overlay.
 *
 * When `open` is true, renders a semi‑transparent backdrop and a
 * centered content box. Clicking the close button will invoke the
 * provided `onClose` callback. The modal does not manage focus
 * trapping; that could be added using Headless UI's Dialog component
 * once dependencies are installed.
 */
export default function Modal({ open, onClose, children }: ModalProps) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="relative bg-white rounded-lg p-4 min-w-[300px] shadow-lg">
        <button
          className="absolute top-2 right-2 text-slate-500 hover:text-slate-700"
          onClick={onClose}
        >
          ×
        </button>
        {children}
      </div>
    </div>
  );
}