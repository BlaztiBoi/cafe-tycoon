/**
 * Game balance constants for Coffee Tycoon.
 *
 * These values control the cost of items, the timing of actions and the
 * customer spawn rates. Centralising them makes it easy to tweak the
 * game's economy without touching core logic. In a production build you
 * might load these from a remote config or user difficulty settings.
 */
export const BALANCE = {
  prices: {
    coffee: 8,
    pastry: 6,
    machine: { base: 20, extra: 80 },
    beansPack: 5,
    flourPack: 6,
    upgrades: {
      brewSpeed1: 50,
      brewSpeed2: 100,
      queue1: 40,
      carafe: 80,
      ovenSpeed1: 60,
    },
    employees: { cashier: 120, brewer: 150, baker: 140 },
  },
  wages: { cashier: 5, brewer: 6, baker: 6 },
  times: { brew: [20000, 16000, 12000], bake: [25000, 20000] },
  spawn: { intervalMin: 15000, intervalMax: 20000, queueLimit: 3 },
};