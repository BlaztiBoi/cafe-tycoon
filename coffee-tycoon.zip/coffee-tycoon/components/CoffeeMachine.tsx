import { useGameStore } from '../lib/gameStore';

/**
 * Coffee machine grid component.
 *
 * Renders a button for each machine in the Zustand store. When clicked,
 * the machine's `startBrew` action is dispatched. The UI shows the
 * machine's current status. In later iterations, this component can be
 * expanded to display brewing progress or multiple tiers of upgrades.
 */
export default function CoffeeMachine() {
  const machines = useGameStore((state) => state.machines);
  const startBrew = useGameStore((state) => state.startBrew);

  if (machines.length === 0) {
    return <div className="text-sm text-slate-500">No coffee machines yet</div>;
  }

  return (
    <div className="flex flex-col gap-2 items-center">
      {machines.map((machine) => (
        <button
          key={machine.id}
          className="btn-primary w-32 text-center"
          onClick={() => startBrew(machine.id)}
        >
          {machine.status === 'idle' && 'Brew'}
          {machine.status === 'brewing' && 'Brewing…'}
          {machine.status === 'done' && 'Done'}
        </button>
      ))}
    </div>
  );
}