import CustomerCard from './CustomerCard';
import { useGameStore } from '../lib/gameStore';

/**
 * Row of customers currently waiting in line.
 *
 * Iterates over the `customers` array in the store and renders a
 * `CustomerCard` for each. Accept and decline actions are passed
 * through directly. In a real implementation you'd likely want to
 * memoize or further split this component to avoid unnecessary
 * re‑renders when unrelated state changes.
 */
export default function CustomersRow() {
  const customers = useGameStore((state) => state.customers);
  const acceptOrder = useGameStore((state) => state.acceptOrder);
  const declineOrder = useGameStore((state) => state.declineOrder);

  if (!customers || customers.length === 0) {
    return <div className="p-4 text-sm text-slate-500">No customers in line</div>;
  }

  return (
    <section className="flex gap-4 p-4 overflow-x-auto">
      {customers.map((c) => (
        <CustomerCard key={c.id} c={c} onAccept={acceptOrder} onDecline={declineOrder} />
      ))}
    </section>
  );
}