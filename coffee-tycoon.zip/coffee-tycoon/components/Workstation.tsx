import CoffeeMachine from './CoffeeMachine';
import Oven from './Oven';
import Register from './Register';

/**
 * Workstation container housing the player's interactive equipment.
 *
 * In the MVP there may only be one machine and one oven, but the
 * workstation lays them out side‑by‑side in a responsive row. This file
 * doesn't handle any game logic beyond rendering each subcomponent.
 */
export default function Workstation() {
  return (
    <section className="flex justify-between gap-4 p-4 bg-slate-50 flex-wrap">
      <div className="flex-1 min-w-[150px] flex justify-center">
        <Oven />
      </div>
      <div className="flex-1 min-w-[150px] flex justify-center">
        <CoffeeMachine />
      </div>
      <div className="flex-1 min-w-[150px] flex justify-center">
        <Register />
      </div>
    </section>
  );
}