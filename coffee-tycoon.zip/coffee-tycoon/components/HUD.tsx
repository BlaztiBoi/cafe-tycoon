import { useGameStore } from '../lib/gameStore';

/**
 * Heads‑up display showing high‑level game stats.
 *
 * Displays current money, the current day number and reputation. As the
 * project evolves, more information (like time of day or supplies) can be
 * surfaced here. The HUD listens to the Zustand store so that state
 * changes trigger re‑renders automatically.
 */
export default function HUD() {
  const money = useGameStore((state) => state.money);
  const day = useGameStore((state) => state.day);
  const reputation = useGameStore((state) => state.reputation);

  return (
    <div className="w-full bg-white shadow py-3 px-4 flex justify-between items-center">
      <div className="font-semibold text-lg">${money.toFixed(2)}</div>
      <div>Day {day}</div>
      <div>⭐ {reputation}</div>
    </div>
  );
}