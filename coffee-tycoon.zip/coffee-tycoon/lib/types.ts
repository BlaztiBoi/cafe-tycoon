/**
 * Shared TypeScript types used throughout the Coffee Tycoon game.
 *
 * These interfaces mirror the structures described in the design
 * specification. Defining them centrally allows UI components and
 * the Zustand store to share a common contract.
 */

export type ItemId = 'coffee' | 'pastry';
export type SupplyId = 'beans' | 'flour';

export interface GameState {
  day: number;
  timeMs: number; // 0..300000 (5 minutes)
  money: number;
  reputation: number; // 0..100
  supplies: Record<SupplyId, number>;
  machines: Machine[];
  oven?: Oven | null;
  register: { floatBills: Bill[] };
  queueLimit: number;
  customers: Customer[];
  orders: Order[];
  employees: Employee[];
  unlocks: UnlockFlags;
  settings: { sound: boolean; autosave: boolean };
}

export interface Machine {
  id: string;
  level: number; // affects brewTime
  status: 'idle' | 'brewing' | 'done';
  brewEndsAt?: number;
  buffer: number; // finished cups not yet picked up
}

export interface Oven {
  id: string;
  level: number;
  status: 'idle' | 'baking' | 'done';
  bakeEndsAt?: number;
  buffer: number;
}

export interface Customer {
  id: string;
  name: string;
  patienceEndsAt: number;
  order: Order;
  accepted: boolean;
}

export interface Order {
  id: string;
  items: { item: ItemId; qty: number }[];
  price: number;
  status: 'waiting' | 'inProgress' | 'ready' | 'served' | 'expired';
}

export interface Employee {
  id: string;
  role: 'cashier' | 'brewer' | 'baker';
  tier: 1 | 2 | 3;
  speedMod: number; // e.g., 0.9 = 10% faster
  misServeChance: number; // 0..0.05
  active: boolean;
}

export interface Bill {
  id: string;
  amount: number;
  spawnAt: number;
}

export type UnlockFlags = Record<string, boolean>;