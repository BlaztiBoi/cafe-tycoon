/**
 * Tailwind CSS configuration.
 *
 * The `content` paths tell Tailwind where to look for class names so it can
 * purge unused styles in production builds. We include the `app` and
 * `components` directories where most UI code will live.
 */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
    "./components/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};