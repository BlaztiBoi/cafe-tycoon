import './globals.css';
import type { ReactNode } from 'react';

/**
 * Root layout for the Coffee Tycoon application.
 *
 * This component wraps all pages with the global styles defined in
 * `globals.css` and sets some basic HTML attributes. It's part of the
 * experimental App Router in Next.js. The `metadata` export can be used
 * by Next.js to set document head tags.
 */
export const metadata = {
  title: 'Coffee Tycoon',
  description: 'A coffee shop idle time‑management game built with Next.js',
};

export default function RootLayout({
  children,
}: {
  children: ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-slate-100 text-slate-900">
        {children}
      </body>
    </html>
  );
}