import { useGameStore } from '../lib/gameStore';

/**
 * Pastry oven component.
 *
 * Shows a single button representing the oven. Clicking the button
 * triggers the `startBake` action if the oven is idle. The oven is
 * optional; if the player hasn't unlocked it yet the component returns
 * null.
 */
export default function Oven() {
  const oven = useGameStore((state) => state.oven);
  const startBake = useGameStore((state) => state.startBake);

  if (!oven) return <div className="text-sm text-slate-500">No oven yet</div>;

  return (
    <button
      className="btn-primary w-32 text-center"
      onClick={() => startBake && startBake()}
    >
      {oven.status === 'idle' && 'Bake'}
      {oven.status === 'baking' && 'Baking…'}
      {oven.status === 'done' && 'Done'}
    </button>
  );
}