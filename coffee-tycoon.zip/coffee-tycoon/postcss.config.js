/**
 * PostCSS configuration for Tailwind CSS.
 *
 * This file tells PostCSS to use Tailwind and autoprefixer when
 * processing CSS files. Next.js will pick this up automatically
 * during build and dev modes.
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};