import { useGameStore } from '../lib/gameStore';

/**
 * Register component.
 *
 * Displays a button for each outstanding bill floating at the register. When
 * clicked, the `collectBill` action is dispatched and the player's money
 * increases accordingly. If there are no bills, a placeholder is shown.
 */
export default function Register() {
  const bills = useGameStore((state) => state.register.floatBills);
  const collectBill = useGameStore((state) => state.collectBill);

  if (!bills || bills.length === 0) {
    return <div className="text-sm text-slate-500">No cash to collect</div>;
  }

  return (
    <div className="flex flex-col gap-2 items-center">
      {bills.map((bill) => (
        <button
          key={bill.id}
          className="btn-primary w-32 text-center"
          onClick={() => collectBill(bill.id)}
        >
          Collect ${bill.amount}
        </button>
      ))}
    </div>
  );
}