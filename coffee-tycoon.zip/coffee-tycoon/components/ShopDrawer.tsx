import { useState } from 'react';

/**
 * Collapsible shop drawer component.
 *
 * This bottom‑anchored panel slides into view when toggled open. It will
 * eventually host the supplies, upgrades and employees tabs, but for now
 * serves as a placeholder. The button in the upper right toggles the
 * drawer open and closed.
 */
export default function ShopDrawer() {
  const [open, setOpen] = useState(false);

  return (
    <div
      className={
        `fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow transition-transform duration-300 ` +
        (open ? 'translate-y-0' : 'translate-y-full')
      }
    >
      <button
        className="absolute -top-10 right-4 bg-emerald-600 text-white px-3 py-1 rounded-t-xl"
        onClick={() => setOpen(!open)}
      >
        {open ? 'Close' : 'Shop'}
      </button>
      <div className="p-4">
        <h2 className="text-lg font-semibold mb-2">Shop</h2>
        <p className="text-sm text-slate-500">
          Supplies, upgrades and employees will appear here in future builds.
        </p>
      </div>
    </div>
  );
}