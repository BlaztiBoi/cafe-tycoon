import type { ReactNode } from 'react';

interface TooltipProps {
  children: ReactNode;
  text: string;
}

/**
 * Simple tooltip wrapper.
 *
 * When hovered, displays a small text box above the child. This component
 * relies purely on CSS for showing/hiding the tooltip. For accessibility
 * reasons you may want to enhance this with ARIA attributes in the future.
 */
export default function Tooltip({ children, text }: TooltipProps) {
  return (
    <span className="relative group inline-block">
      {children}
      <span className="absolute left-1/2 -translate-x-1/2 mt-2 opacity-0 group-hover:opacity-100 bg-black text-white text-xs rounded py-1 px-2 pointer-events-none whitespace-nowrap z-10">
        {text}
      </span>
    </span>
  );
}