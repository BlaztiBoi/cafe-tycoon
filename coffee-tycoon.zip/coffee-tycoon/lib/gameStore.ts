import create from 'zustand';
import type { GameState, ItemId, Employee, Machine, Bill } from './types';

/**
 * Zustand store definition for Coffee Tycoon.
 *
 * The store holds all game state and exposes a set of actions that
 * components can dispatch. Many actions are stubbed out for the MVP
 * skeleton; you can fill these in with full logic according to the
 * specification. The store can later be extended to include middleware
 * for persistence (e.g. localStorage autosave).
 */

interface GameActions {
  acceptOrder: (customerId: string) => void;
  declineOrder: (customerId: string) => void;
  startBrew: (machineId: string) => void;
  finishBrew: (machineId: string) => void;
  pickUpCup: (machineId: string) => void;
  serveCustomer: (customerId: string, item: ItemId) => void;
  collectBill: (billId: string) => void;
  buy: (itemKey: string) => void;
  hire: (role: Employee['role']) => void;
  gameTick: (deltaMs: number) => void;
  startBake: () => void;
}

type Store = GameState & GameActions;

// Initial state for the game. When extending the game, remember to also
// update this initializer so new fields are defined.
const initialState: GameState = {
  day: 1,
  timeMs: 0,
  money: 30,
  reputation: 50,
  supplies: { beans: 0, flour: 0 },
  machines: [],
  oven: null,
  register: { floatBills: [] },
  queueLimit: 3,
  customers: [],
  orders: [],
  employees: [],
  unlocks: {},
  settings: { sound: true, autosave: true },
};

export const useGameStore = create<Store>((set, get) => ({
  ...initialState,

  /**
   * Accept a customer's order. Sets their `accepted` flag to true. In a
   * full implementation you'd also allocate the order to the active
   * orders list and handle queue limits.
   */
  acceptOrder: (customerId: string) => {
    set((state) => ({
      customers: state.customers.map((c) =>
        c.id === customerId ? { ...c, accepted: true } : c
      ),
    }));
  },

  /**
   * Decline a customer's order. Removes them from the queue without
   * penalty in the MVP.
   */
  declineOrder: (customerId: string) => {
    set((state) => ({
      customers: state.customers.filter((c) => c.id !== customerId),
    }));
  },

  /**
   * Initiate brewing on a machine. For now this just marks the machine as
   * brewing without consuming supplies or checking orders. Full logic
   * should verify there is a coffee order in the queue and that beans are
   * available.
   */
  startBrew: (machineId: string) => {
    set((state) => ({
      machines: state.machines.map((m) =>
        m.id === machineId && m.status === 'idle'
          ? { ...m, status: 'brewing', brewEndsAt: state.timeMs + 20000 }
          : m
      ),
    }));
  },

  /**
   * Mark a machine's brewing as finished. This is a stub for game tick
   * logic; in practice this would be called automatically when the
   * `brewEndsAt` time is reached.
   */
  finishBrew: (machineId: string) => {
    set((state) => ({
      machines: state.machines.map((m) =>
        m.id === machineId ? { ...m, status: 'done', brewEndsAt: undefined, buffer: m.buffer + 1 } : m
      ),
    }));
  },

  /**
   * Pick up a finished cup from a machine's buffer. Reduces the buffer
   * count and returns the cup to the player's cursor. Here we simply
   * decrement the buffer without tracking the cursor.
   */
  pickUpCup: (machineId: string) => {
    set((state) => ({
      machines: state.machines.map((m) =>
        m.id === machineId && m.buffer > 0
          ? { ...m, buffer: m.buffer - 1, status: m.buffer - 1 > 0 ? 'done' : 'idle' }
          : m
      ),
    }));
  },

  /**
   * Serve a customer an item. For now this simply removes the first
   * customer in the list and spawns a cash bill. In a full game you'd
   * verify the customer requested the item and adjust reputation.
   */
  serveCustomer: (customerId: string, item: ItemId) => {
    set((state) => {
      const customerIndex = state.customers.findIndex((c) => c.id === customerId);
      if (customerIndex < 0) return {};
      const customer = state.customers[customerIndex];
      // generate a bill equal to the order price
      const bill: Bill = {
        id: `bill_${Date.now()}`,
        amount: customer.order.price,
        spawnAt: state.timeMs,
      };
      return {
        customers: state.customers.filter((c) => c.id !== customerId),
        register: { floatBills: [...state.register.floatBills, bill] },
      };
    });
  },

  /**
   * Collect a bill from the register. Transfers the bill amount into the
   * player's money.
   */
  collectBill: (billId: string) => {
    set((state) => {
      const bill = state.register.floatBills.find((b) => b.id === billId);
      if (!bill) return {};
      return {
        money: state.money + bill.amount,
        register: {
          floatBills: state.register.floatBills.filter((b) => b.id !== billId),
        },
      };
    });
  },

  /**
   * Buy an item from the shop. Supports purchasing a coffee machine or
   * packs of beans. Costs and quantities are hard‑coded for the MVP
   * demonstration but should be migrated to the balance module.
   */
  buy: (itemKey: string) => {
    set((state) => {
      switch (itemKey) {
        case 'machine': {
          const cost = 20;
          if (state.money < cost) return {};
          const newMachine: Machine = {
            id: `machine_${state.machines.length + 1}`,
            level: 1,
            status: 'idle',
            buffer: 0,
          };
          return {
            money: state.money - cost,
            machines: [...state.machines, newMachine],
          };
        }
        case 'beansPack': {
          const cost = 5;
          if (state.money < cost) return {};
          return {
            money: state.money - cost,
            supplies: { ...state.supplies, beans: state.supplies.beans + 10 },
          };
        }
        default:
          return {};
      }
    });
  },

  /**
   * Hire an employee. This stub simply pushes a new employee into the
   * employees array without checking cost or wages.
   */
  hire: (role: Employee['role']) => {
    set((state) => {
      const newEmployee: Employee = {
        id: `emp_${Date.now()}`,
        role,
        tier: 1,
        speedMod: 1,
        misServeChance: 0.05,
        active: true,
      };
      return {
        employees: [...state.employees, newEmployee],
      };
    });
  },

  /**
   * Advance the game by a given delta of milliseconds. This stub simply
   * increments the internal clock. In a complete game loop you'd also
   * spawn customers, decrement patience timers, resolve stations and
   * evaluate employee AI.
   */
  gameTick: (deltaMs: number) => {
    set((state) => ({
      timeMs: state.timeMs + deltaMs,
    }));
  },

  /**
   * Start baking a pastry. Like `startBrew`, this merely flips the oven
   * status. Full logic should verify flour supplies and order needs.
   */
  startBake: () => {
    set((state) => {
      const oven = state.oven;
      if (!oven || oven.status !== 'idle') return {};
      return {
        oven: { ...oven, status: 'baking', bakeEndsAt: state.timeMs + 25000 },
      };
    });
  },
}));