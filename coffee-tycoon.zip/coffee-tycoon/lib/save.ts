import type { GameState } from './types';

/**
 * Simple localStorage persistence helpers.
 *
 * These functions wrap JSON serialisation and provide graceful failure
 * handling. They should only be called in a browser context where
 * `window.localStorage` is available.
 */
export function saveState(state: GameState) {
  try {
    const json = JSON.stringify(state);
    window.localStorage.setItem('coffee-tycoon-save', json);
  } catch (e) {
    console.warn('Failed to save game state', e);
  }
}

export function loadState(): GameState | null {
  try {
    const raw = window.localStorage.getItem('coffee-tycoon-save');
    if (!raw) return null;
    return JSON.parse(raw) as GameState;
  } catch (e) {
    console.warn('Failed to load game state', e);
    return null;
  }
}